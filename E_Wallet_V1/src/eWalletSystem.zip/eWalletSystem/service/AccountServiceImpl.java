package eWalletSystem.service;

import eWalletSystem.model.Account;
import eWalletSystem.model.EWalletSystem;

public class AccountServiceImpl implements AccountService {

    private EWalletSystem eWalletSystem=new EWalletSystem();

    @Override
    public Boolean createAccount(Account account) {
       Boolean isAccountExist =eWalletSystem.getAccount().stream()
               .anyMatch(account1 -> account1.getUserName().equals(account.getUserName()));

       if (isAccountExist) return false;

       eWalletSystem.getAccount().add(account);

        return true;
    }

    @Override
    public Boolean isAccountExistByUserNameAndPassword(Account account) {
        Boolean isAccountExist =eWalletSystem.getAccount().stream()
                .anyMatch(account1 -> account1.getUserName().equals(account.getUserName())&&
                        account1.getPassword().equals(account.getPassword()));

        return isAccountExist;


    }


}
