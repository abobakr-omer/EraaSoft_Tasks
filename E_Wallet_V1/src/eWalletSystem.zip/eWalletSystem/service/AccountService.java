package eWalletSystem.service;

import eWalletSystem.model.Account;

public interface AccountService {

    Boolean createAccount(Account account);

    Boolean isAccountExistByUserNameAndPassword(Account account);



}
